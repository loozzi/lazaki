from src.config.config import Config
from src.config.env_config import EnvConfig

_config = Config()
envConfig = EnvConfig()
