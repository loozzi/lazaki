class DevConfig:
    def __init__(self) -> None:
        self.ENV = "development"
        self.DEBUG = True
        self.PORT = 8080
        self.HOST = "0.0.0.0"
