class ProdConfig:
    def __init__(self) -> None:
        self.ENV = "production"
        self.DEBUG = False
        self.PORT = 80
        self.HOST = "0.0.0.0"
