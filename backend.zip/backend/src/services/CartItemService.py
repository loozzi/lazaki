class CartItemService:
    # Lấy sản phẩm trong Cart
    def getCartItem(productId):
        pass
