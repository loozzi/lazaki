class Model:
    def model():
        pass
