class ModelRecommendInterface:
    def model():
        pass
